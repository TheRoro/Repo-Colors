# 🎨 Repo Colors 🎨

This extension will make your repositories look stunning and will give personality to your profile. The repository's color will match the primary language/technology of its development. Additionally, every language has a carefully chosen unique color palette based on the programming language/technology logo.

🎨 Repo Colors 🎨 currently has color support for this technologies:
JavaScript, Vue, Java, TypeScript, Python, Go, HTML, C++, C#, CSS, SCSS, Sass, Jupyter Notebook, Vim, VimL, TeX, Swift, Kotlin, Dart, Gherkin, Objective-C, R, Powershell, Shell, Cuda, Lua, PHP, Ruby, CoffeeScript, Rust, Dockerfile, and AutoHotKey.

Rebol, C, PureBasic, Makefile, Visual, D, and Lisp currently have the same color. Feel free to suggest us a color palette for this technologies!